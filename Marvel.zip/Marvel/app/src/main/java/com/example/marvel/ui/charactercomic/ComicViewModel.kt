package com.example.marvel.ui.charactercomic

class ComicViewModel {
}