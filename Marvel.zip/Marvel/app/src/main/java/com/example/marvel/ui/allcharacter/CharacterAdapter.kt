package com.example.marvel.ui.allcharacter

class CharacterAdapter {
}