package com.example.marvel.ui.allcharacter

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import com.example.marvel.R


class Character_Fragment : Fragment(R.layout.fragment__character),  {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }


}