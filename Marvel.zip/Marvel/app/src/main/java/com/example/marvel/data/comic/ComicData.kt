package com.example.marvel.data.comic

data class ComicData(val results: List<ComicResult>)