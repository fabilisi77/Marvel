package com.example.marvel.api.repository




class MarvelRepository{
    suspend fun getAllCharacters

}