package com.example.marvel.data.comic

data class ComicResponse(val data: ComicData)