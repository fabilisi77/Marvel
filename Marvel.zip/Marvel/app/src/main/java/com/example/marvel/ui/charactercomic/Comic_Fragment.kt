package com.example.marvel.ui.charactercomic


import androidx.fragment.app.Fragment
import com.example.marvel.R



class Comic_Fragment(private val characterId: String):
    Fragment(R.layout.fragment_comic),{

        private val _binding



}